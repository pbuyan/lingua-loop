---
applyTo: "src/**/*.tsx,src/**/*.css,tailwind.config.ts"
---

# Styling-specific Instructions

Rules for visual styling. Apply when writing JSX with classes, editing CSS, or touching the Tailwind config.

## Source of Truth

All design tokens — colors, spacing, typography, breakpoints, shadows, radii — live in `tailwind.config.ts`. Never hardcode hex values, rem/px sizes, or font names directly in components.

If a value is missing from the tokens, add it to the config — don't inline a one-off.

## Class Composition

Always merge classes through the `cn()` helper (`src/lib/utils/cn.ts`, which wraps `clsx` and `tailwind-merge`):

```tsx
import { cn } from '@/lib/utils/cn';

<div className={cn(
  'rounded-lg border p-4',
  isActive && 'border-blue-500 bg-blue-50',
  className,
)} />
```

This handles conditional classes and last-class-wins conflicts cleanly.

For components with discrete variants, use `class-variance-authority`:

```tsx
import { cva, type VariantProps } from 'class-variance-authority';

const badgeVariants = cva('inline-flex items-center rounded-full px-2 py-1 text-xs font-medium', {
  variants: {
    tone: {
      neutral: 'bg-gray-100 text-gray-800',
      success: 'bg-green-100 text-green-800',
      warning: 'bg-yellow-100 text-yellow-800',
      danger:  'bg-red-100 text-red-800',
    },
  },
  defaultVariants: { tone: 'neutral' },
});

type BadgeProps = VariantProps<typeof badgeVariants> & { children: ReactNode };
```

## When to Use What

- **Tailwind utilities** — the default. 95% of cases.
- **CSS Modules** — when a component genuinely needs complex selectors, animations, or escapes Tailwind's expressiveness. File next to the component: `Foo.module.css`.
- **Global CSS** (`src/styles/`) — only for resets, root variables, font imports, and animation keyframes used in multiple places.
- **Inline `style={}`** — only for genuinely dynamic values (`style={{ transform: \`translateX(\${x}px)\` }}`). Never for static styling.

## Responsive Design

- Mobile-first. Start with the smallest viewport, add breakpoint prefixes for larger screens.
- Use Tailwind's standard breakpoints (`sm`, `md`, `lg`, `xl`, `2xl`). Don't invent custom ones without a reason.
- Test layouts at every breakpoint, not just the design comps.

## Dark Mode

If the project supports dark mode (check `tailwind.config.ts` for `darkMode`), use `dark:` prefixes alongside light defaults:

```tsx
<div className="bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100">
```

Don't read `prefers-color-scheme` directly — the theme provider handles it.

## Accessibility (Visual)

- **Color contrast** — meet WCAG AA: 4.5:1 for body text, 3:1 for large text and UI elements. Use the design system tokens; they're calibrated. When in doubt, run the axe scan.
- **Focus indicators** — never use `outline-none` without replacing it with a visible focus ring (`focus-visible:ring-2 focus-visible:ring-blue-500`).
- **Motion** — respect `prefers-reduced-motion`. For meaningful animations, gate them: `motion-safe:animate-bounce`.
- **Don't communicate state with color alone** — pair with an icon, text, or pattern.

## Performance

- Avoid huge inline class strings that change on every render with dynamic interpolation — extract to `cva` or a helper.
- Don't ship unused Tailwind classes — the build prunes them, but only if class names are statically analyzable. No `className={\`text-\${color}-500\`}` — use a lookup map instead.

## Don't

- Don't reach for a CSS-in-JS library. We're standardized on Tailwind.
- Don't override third-party component styles with `!important`. Configure them properly or wrap them.
- Don't nest more than two or three Tailwind responsive/state prefixes on a single utility. If it's getting unreadable, extract a variant.
- Don't mix Tailwind and CSS Modules on the same element without reason. Pick one per element.
