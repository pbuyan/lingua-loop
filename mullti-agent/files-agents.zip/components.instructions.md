---
applyTo: "src/components/**/*.tsx"
---

# Component-specific Instructions

These rules apply only when working on files under `src/components/`. They extend (do not replace) the project-wide rules in `copilot-instructions.md`.

## Two Categories

- `src/components/ui/` — **generic primitives** (Button, Input, Modal, Tooltip). Reusable across any feature. No business logic, no data fetching.
- `src/components/features/` — **feature-specific composites**. Can fetch data, can know about domain models, can compose ui primitives.

If you're about to put domain knowledge into a `ui/` component, stop — it belongs in `features/`.

## File Layout per Component

For non-trivial components, use a folder:

```
ComponentName/
├── ComponentName.tsx          # Implementation
├── ComponentName.test.tsx     # Unit/integration tests
├── ComponentName.stories.tsx  # Storybook (ui primitives only, or complex features)
├── index.ts                   # Re-export
└── README.md                  # Only if the component is non-obvious
```

For trivial single-file components, just `ComponentName.tsx` is fine.

## Props

- Type named `<ComponentName>Props`.
- Destructure in the signature.
- Required props before optional. Group related props.
- Accept `className` for outer styling overrides. Merge with `cn()`:

```tsx
type ButtonProps = {
  variant?: 'primary' | 'secondary';
  className?: string;
  children: ReactNode;
} & ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({ variant = 'primary', className, children, ...rest }: ButtonProps) {
  return (
    <button className={cn(buttonVariants({ variant }), className)} {...rest}>
      {children}
    </button>
  );
}
```

- For components with multiple visual variants, use `class-variance-authority`:

```tsx
const buttonVariants = cva('inline-flex items-center rounded font-medium', {
  variants: {
    variant: {
      primary: 'bg-blue-600 text-white hover:bg-blue-700',
      secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300',
    },
    size: { sm: 'px-2 py-1 text-sm', md: 'px-4 py-2', lg: 'px-6 py-3 text-lg' },
  },
  defaultVariants: { variant: 'primary', size: 'md' },
});
```

## Accessibility Checklist (per component)

- Correct semantic element? (`button`, not `div`; `nav`, not `div`)
- Keyboard operable? (Tab focusable, Enter/Space activates buttons, Escape closes modals)
- Focus visible? (Don't remove the outline without replacing it.)
- Labels? (`aria-label` or visible label or `aria-labelledby`)
- Live regions for dynamic content? (`aria-live` for toast notifications)
- Color contrast? (Never communicate state with color alone — pair with icon or text)

## Composition Over Configuration

Prefer:
```tsx
<Card>
  <CardHeader>Title</CardHeader>
  <CardBody>...</CardBody>
</Card>
```
Over:
```tsx
<Card header="Title" body="..." />
```

Composition scales; configuration explodes prop interfaces.

## Don't

- Don't put data fetching in `ui/` components.
- Don't accept `style` as a prop unless dynamic values genuinely require it — use `className` and Tailwind.
- Don't reach into a child's internals via refs unless absolutely necessary (and even then, prefer `forwardRef` and document why).
- Don't add `data-testid` unless an accessibility query is impossible.
- Don't import from `pages/` into `components/`. Direction is one-way: pages → features → ui.
