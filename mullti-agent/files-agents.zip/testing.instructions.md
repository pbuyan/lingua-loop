---
applyTo: "**/*.test.ts,**/*.test.tsx,e2e/**/*.spec.ts"
---

# Testing-specific Instructions

Rules that apply when working in test files. These extend the Tester chat mode and `copilot-instructions.md`.

## Stack Reminder

- Unit/integration: Vitest + React Testing Library + `@testing-library/jest-dom` + `@testing-library/user-event`
- Network: MSW handlers in `src/test/mocks/`
- E2E: Playwright in `e2e/`
- Custom render in `src/test/utils.tsx` (provides QueryClient, Router, theme providers)

## Always

- Import `render` and `screen` from `@/test/utils`, not directly from `@testing-library/react`. The custom `render` provides required providers.
- Use `userEvent.setup()` at the top of each test, not the deprecated direct `userEvent.click()` form.
- Use `findBy*` (async) when waiting for elements that appear after async work. Use `getBy*` (sync) when the element is present immediately. Use `queryBy*` only to assert absence.
- Use `vi.fn()` for spies, `vi.spyOn()` for partial mocks, `vi.mock()` for module mocks. Reset with `beforeEach`.
- Use `expect.poll` or `waitFor` for async assertions — never `setTimeout`.
- For MSW: define realistic handlers in `src/test/mocks/handlers.ts`; override per-test with `server.use()`.

## Querying Priority

```
1. getByRole         ← almost always start here
2. getByLabelText    ← for form inputs
3. getByPlaceholderText
4. getByText
5. getByDisplayValue
6. getByAltText
7. getByTitle
8. getByTestId       ← last resort, add a comment explaining why
```

If you reach for `getByTestId`, ask: "Could a screen reader user find this?" If yes, there's an accessible query for it.

## Structure

```ts
describe('ComponentOrFeature', () => {
  describe('when <condition>', () => {
    it('does <expected behavior>', async () => {
      // Arrange
      const user = userEvent.setup();
      render(<Component />);

      // Act
      await user.click(screen.getByRole('button', { name: /submit/i }));

      // Assert
      expect(await screen.findByText(/success/i)).toBeInTheDocument();
    });
  });
});
```

Nested `describe` for context groupings is fine. Don't over-nest — two levels deep is usually plenty.

## Async

- Anything that triggers a state update should be awaited (`await user.click(...)`, `await user.type(...)`).
- Anything that depends on async work being complete uses `findBy*` or `await waitFor(...)`.
- Wrapping in `act` is almost never necessary with modern Testing Library — if you're doing it, you're probably masking a missing `await`.

## MSW Patterns

Default handlers cover happy paths. Per-test overrides cover failure modes:

```ts
import { http, HttpResponse } from 'msw';
import { server } from '@/test/mocks/server';

it('shows an error when the server returns 500', async () => {
  server.use(
    http.get('/api/invoices', () => new HttpResponse(null, { status: 500 }))
  );
  render(<InvoiceList />);
  expect(await screen.findByRole('alert')).toBeInTheDocument();
});
```

Don't mock the API client directly. Mock the network.

## Hooks

```ts
import { renderHook, waitFor } from '@testing-library/react';
import { wrapper } from '@/test/utils';

it('returns invoices for the given filter', async () => {
  const { result } = renderHook(() => useInvoices({ status: 'unpaid' }), { wrapper });
  await waitFor(() => expect(result.current.isSuccess).toBe(true));
  expect(result.current.data).toHaveLength(3);
});
```

## Don't

- Don't snapshot entire components. Snapshots are useful for stable serialized output (rendered Markdown, normalized data) — not for whole component trees.
- Don't test third-party libraries.
- Don't share variables between tests (mutable state, module-level data). Each test starts fresh.
- Don't use `screen.debug()` in committed code.
- Don't disable tests with `it.skip` or `describe.skip` without a `// TODO: <issue-link>` comment.
- Don't use real timers (`setTimeout`, `setInterval`) without `vi.useFakeTimers()`.
- Don't test private implementation details. Test what the user sees and does.

## E2E (Playwright)

- Cover **critical user journeys** only: login, primary feature flows, payment if applicable. Not every interaction.
- Use Playwright's `getByRole` and `getByLabel` — same accessibility-first philosophy.
- Each spec independent: no shared state between specs. Use `test.beforeEach` for setup.
- Use Playwright's automatic waiting. Don't add manual `waitForTimeout` calls.
- Run against a deployed preview or local Vite dev server — never against production.
