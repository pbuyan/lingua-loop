# Copilot Configuration — How It Works

This directory configures GitHub Copilot to behave consistently with our team's conventions and to operate as a small set of specialized "agents" via custom chat modes.

## File Map

```
.github/
├── copilot-instructions.md          # Always-on, applies to every Copilot Chat request
├── instructions/
│   ├── components.instructions.md   # Auto-applies to src/components/**/*.tsx
│   ├── hooks.instructions.md        # Auto-applies to src/hooks/** and src/lib/api/queries/**
│   ├── testing.instructions.md      # Auto-applies to *.test.ts(x) and e2e/*.spec.ts
│   └── styles.instructions.md       # Auto-applies to *.tsx, *.css, tailwind.config.ts
└── chatmodes/
    ├── planner.chatmode.md          # Invoke with /planner    — produces a plan, no code
    ├── implementer.chatmode.md      # Invoke with /implementer — executes a plan
    ├── tester.chatmode.md           # Invoke with /tester     — writes tests
    ├── reviewer.chatmode.md         # Invoke with /reviewer   — review-only, no edits
    └── documenter.chatmode.md       # Invoke with /documenter — updates docs/JSDoc/CHANGELOG
```

## How the Layers Combine

For any Copilot Chat request, the effective system prompt is:
1. **`copilot-instructions.md`** (always included)
2. **Any `*.instructions.md`** whose `applyTo` glob matches files currently in context
3. **The active chat mode's** `*.chatmode.md` (if you've selected one)

This means: in `/implementer` mode editing a `.test.tsx` file, Copilot sees the project rules + testing rules + implementer behavior — all at once.

## Typical Feature Workflow

1. **Plan** — open Copilot Chat, select `/planner` mode, paste the feature request. Save output to `docs/plans/<feature>.md`.
2. **Implement** — switch to `/implementer`, point at the plan, work task-by-task. Use Agent Mode for multi-file edits.
3. **Test** — switch to `/tester`, point at the new code or the plan's Test Plan section.
4. **Review** — switch to `/reviewer`, point at your diff. Address blockers and should-fixes.
5. **Document** — switch to `/documenter`, point at the diff. Update README, JSDoc, CHANGELOG.
6. **Open PR** — human review, CI gates, merge.

For very small tasks (bump a dep, fix a type, add a missing prop), skip the ceremony and use plain Copilot Chat or assign a GitHub issue to **Copilot Coding Agent**.

## Customizing for Your Work

- These files are project artifacts. Edit them, propose changes via PR, evolve them as the project teaches us new patterns.
- Don't make them too long. Verbose instructions get ignored. Cut what's not earning its place.
- When in doubt about a rule, run a quick test: write the same prompt with and without it, compare output quality.

## When Things Go Wrong

- **Copilot ignores a rule:** check that the instruction file is committed and that the file you're editing actually matches the `applyTo` glob.
- **Chat mode doesn't appear in the picker:** restart VS Code; ensure the file is in `.github/chatmodes/` and ends in `.chatmode.md`.
- **Conflicting rules between modes:** the more specific layer wins. If unclear, simplify.
- **Hallucinated APIs or wrong library versions:** Copilot's training data can lag. Paste the relevant doc snippet into chat or use `#fetch` to pull real docs.

## Not Configured Here (Yet)

- Cost monitoring — track via GitHub's Copilot admin dashboard.
- MCP servers — add when we need external context (Jira, Figma, internal docs).
- Coding Agent eligibility rules — define via repo labels and a workflow file once we're ready for Phase 1.5.
