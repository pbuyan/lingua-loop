---
applyTo: "src/hooks/**/*.ts,src/hooks/**/*.tsx,src/lib/api/queries/**/*.ts"
---

# Hook-specific Instructions

Rules for custom hooks and TanStack Query hooks.

## General

- Hook name starts with `use`. Always.
- One hook per file. Filename matches hook name: `useInvoices.ts` exports `useInvoices`.
- Hooks live in `src/hooks/` unless colocated with a feature (`src/components/features/<feature>/use<Feature>.ts`).
- Query hooks specifically live in `src/lib/api/queries/`.
- Mutation hooks live in `src/lib/api/mutations/`.
- Public hooks have JSDoc with at least one usage example.

## TanStack Query Conventions

### Query Keys
Centralize query keys per domain to avoid drift:

```ts
// src/lib/api/queries/invoices.ts
export const invoiceKeys = {
  all: ['invoices'] as const,
  lists: () => [...invoiceKeys.all, 'list'] as const,
  list: (filter: InvoiceFilter) => [...invoiceKeys.lists(), filter] as const,
  details: () => [...invoiceKeys.all, 'detail'] as const,
  detail: (id: string) => [...invoiceKeys.details(), id] as const,
};
```

### Query Hooks

```ts
export function useInvoices(filter: InvoiceFilter) {
  return useQuery({
    queryKey: invoiceKeys.list(filter),
    queryFn: () => api.invoices.list(filter),
    staleTime: 30_000,
  });
}
```

- `queryFn` calls a typed API function from `src/lib/api/` — don't put fetch logic inline in the hook.
- Set `staleTime` deliberately. Default of 0 causes excessive refetches.
- Use `select` to derive shape if components need a different view than the raw response.
- Never put server data into Zustand or `useState`. It belongs in the query cache.

### Mutation Hooks

```ts
export function useCreateInvoice() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateInvoiceInput) => api.invoices.create(input),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: invoiceKeys.lists() }),
  });
}
```

- Invalidate related queries on success. Be specific — invalidating `invoiceKeys.all` is rarely necessary.
- For optimistic updates, use `onMutate` + `onError` rollback. Document why optimism is worth the complexity.

## Plain Custom Hooks

For non-query hooks, follow these rules:

- **Return objects, not arrays**, except for the React-style 2-tuple convention (`useState`, `useToggle`).
- **Stabilize callbacks** with `useCallback` only if they're passed to memoized children or used as effect dependencies.
- **Single responsibility.** A hook that does fetching, caching, derived state, and side effects is too much — split it.
- **Pure where possible.** Hooks that do side effects should be obvious about it (`useDebouncedSync`, not `useValue`).

## Effect Discipline

If you find yourself reaching for `useEffect`, first ask:
1. Is this just derived state? → compute during render, no effect.
2. Is this event handling? → put it in the event handler.
3. Is this fetching? → use TanStack Query, not effect+fetch.
4. Is this syncing with an external system (subscription, timer, third-party widget)? → ✅ legitimate effect.

When you do use an effect, the dependency array must be complete and honest. If ESLint warns, fix the cause, don't suppress the warning.

## Testing Hooks

- Use `renderHook` from `@testing-library/react`.
- Wrap with a fresh `QueryClientProvider` for query hooks (helper in `src/test/utils.tsx`).
- Use `waitFor` for async state changes — not arbitrary timeouts.

## Don't

- Don't call hooks conditionally or in loops.
- Don't call hooks outside React components or other hooks.
- Don't fetch in a `useEffect` when TanStack Query is available.
- Don't store derived data in state when you can compute it during render.
- Don't return the raw query object when consumers need a narrower shape — destructure and re-shape.
